//
//  PwCSTTPCordovaPlugin.h
//  SpeechNLPLib
//
//  Created by Padman Balasubramanian on 2/13/18.
//  Copyright © 2018 PricewaterhouseCoopers LLP. All rights reserved.
//

#import "CDV.h"
#import "ISTTPHandler.h"
#import "PwCSTTPLib.h"

@interface PwCSTTPCordovaPlugin : CDVPlugin<ISTTPHandler>

@property(nonatomic, strong) CDVInvokedUrlCommand *savedCmd;
@property (nonatomic, strong) PwCSTTPLib *speechnlp;

- (void)startListening:(CDVInvokedUrlCommand*)command;
- (void)stopListening:(CDVInvokedUrlCommand*)command;

@end
