//
//  PwCSTTPCordovaPlugin.m
//  SpeechNLPLib
//
//  Created by Padman Balasubramanian on 2/13/18.
//  Copyright © 2018 PricewaterhouseCoopers LLP. All rights reserved.
//

#import "PwCSTTPCordovaPlugin.h"

@implementation PwCSTTPCordovaPlugin

-(PwCSTTPLib *)speechnlp{
    NSLog(@"speechnlp constructor");
    if(!_speechnlp){
        NSLog(@"speechnlp object not available");
        _speechnlp = [[PwCSTTPLib alloc]init];
    }
    NSLog(@"returning speechnlp object");
    return _speechnlp;
}

- (void)startListening:(CDVInvokedUrlCommand*)command {
    NSLog(@"startListening");
    self.savedCmd = command;
    self.speechnlp.iDelegate = self;
    [self.speechnlp startRecording];
}

- (void)stopListening:(CDVInvokedUrlCommand*)command {
    NSLog(@"stopListening");
    self.savedCmd = command;
    self.speechnlp.iDelegate = self;
    [self.speechnlp stopRecording];
}

-(void)onSuccess:(NSString *)aStrToken {
    NSLog(@"onSuccess");
    CDVPluginResult* pluginResult = nil;
    pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK
                                     messageAsString:aStrToken];
    NSLog(@"onSuccess resultString [%@]", aStrToken);
    [self.commandDelegate sendPluginResult:pluginResult callbackId:self.savedCmd.callbackId];
}

-(void)onError:(NSError *)aError {
    NSLog(@"onError");
    NSMutableDictionary *errorDictionary = [self nsErrorAsDictionary:aError];
    CDVPluginResult * pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR
                                                   messageAsDictionary:errorDictionary];
    NSLog(@"onError errorString [%@]", aError);
    [self.commandDelegate sendPluginResult:pluginResult callbackId:self.savedCmd.callbackId];
}

-(NSMutableDictionary *)nsErrorAsDictionary:(NSError *)errorIn{
    if(!errorIn) {
        return  [@{@"code": @-1,
                   @"domain": @"PwCSTTPErrorDomain",
                   @"userInfo" : @{@"NSLocalizedDescription":@"An error occurred, but no other information is available."}}
                 mutableCopy];
    }
    NSMutableDictionary *errorDictionary = [@{@"code": [NSNumber numberWithInteger:errorIn.code],
                                              @"domain": [errorIn domain]} mutableCopy ];
    
    if(errorIn.userInfo){
        NSMutableDictionary *userInfo = [[NSMutableDictionary alloc]init];
        for (NSString *key in errorIn.userInfo.allKeys) {
            id object = [errorIn.userInfo objectForKey: key];
            if([@"NSUnderlyingError" isEqualToString:key]){
                // A nested NSError
                NSError *nsError = (NSError *)object;
                userInfo[@"NSUnderlyingError"] = [self nsErrorAsDictionary:nsError];
            }else {
                // TCS Nov 2016 -- using [obj description] made Dictionaries
                // show up as unparseable strings in JS-land
                if ([NSJSONSerialization isValidJSONObject:object] ) {
                    userInfo[key] = object;
                } else {
                    userInfo[key] = [object description];
                }
            }
        }
        errorDictionary[@"userInfo"] = userInfo;
    }
    return errorDictionary;
}

@end
