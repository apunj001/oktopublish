//
//  PwCSTTPLib.h
//  PwCSTTPLib
//
//  Created by Padman Balasubramanian on 2/14/18.
//  Copyright © 2018 PricewaterhouseCoopers LLP. All rights reserved.
//

#ifndef PwCSTTPLib_h
#define PwCSTTPLib_h
#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>
#import "ISTTPHandler.h"

#define BUILD_CONFIG @"Build Config"

#define GOOGLE_SPEECH @"GOOGLE_SPEECH"
#define SVCAPI_KEY @"SVCAPI_KEY"
#define URL @"URL"


#define DIALOG_FLOW @"DIALOG_FLOW"
#define TOKEN @"TOKEN"
#define GUID @"GUID"

#define SAMPLE_RATE 16000

#define STTPLibErrorDomain @"STTPLibErrorDomain"

typedef NS_ENUM(NSInteger, STTPLibErrorCode)
{
    AudioRecorderStartError,
    AudioRecorderStopError,
    GoogleSpeechAPIError,
    DialogFlowAPIError,
} ;

@interface PwCSTTPLib : NSObject <AVAudioRecorderDelegate>

//Public functions--------------------------------------------------

- (void) setSTTPHandler:(id<ISTTPHandler>)aHandler;

-(void) startRecording;
-(void) stopRecording;
-(void) playRecording;

-(NSString *) GetOutputText:(NSString *)result;
-(NSString *) GetIntentMatched:(NSString *)result;
-(NSString *) GetOutputContextMatched:(NSString *)result;
-(NSDictionary *) GetParsedResult:(NSString *)result;
// --------------------------------------------------------------------

@property(nonatomic,weak) id<ISTTPHandler> iDelegate;

@end

#endif /* PwCSTTPLib_h */

