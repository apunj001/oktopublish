//
//  PwCSTTPLib.m
//  PwCSTTPLib
//
//  Created by Padman Balasubramanian on 2/14/18.
//  Copyright © 2018 PricewaterhouseCoopers LLP. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>
#import <String.h>

#import "PwCSTTPLib.h"

@implementation PwCSTTPLib

//RECORDER USED BY THE LIBRARY
AVAudioRecorder *recorder;

//NSTimer *levelTimer2;

//PLIST PARAMS------------------------
NSString * Googlebase = NULL;
NSString * Dialogflowbase = NULL;

NSString * Googleapiurl = NULL;
NSString * Googleapikey = NULL;

NSString * Dialogflowurl = NULL;
NSString * Dialogflowtoken = NULL;
NSString * Dialogflowguid = NULL;

NSTimeInterval interval = 10;
//------------------------

//STORING THE AUDIO FILE
-(NSString *) soundFilePath {
    NSArray *dirPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docsDir = dirPaths[0];
    NSLog(@"soundFilePath [%@]", docsDir);
    return [docsDir stringByAppendingPathComponent:@"sound.caf"];
}

//LOADING CONFIG VALUES
/*
 - (NSMutableDictionary *)loadConfigsFromFile
 {
 NSDictionary *dictionary = [NSDictionary dictionaryWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"PwCSpeechLibplist" ofType:@"plist"]];
 NSLog(@"dictionary = %@", dictionary);
 NSArray *arrayG = [dictionary objectForKey:GOOGLE_SPEECH];
 NSArray *arrayDF = [dictionary objectForKey:DIALOG_FLOW];
 int count=[arrayG count];
 int i=0;
 for (i = 0; i < count; i++)
 NSLog (@"Element G %i = %@", i, [arrayG o);
 
 count=[arrayDF count];
 i=0;
 for (i = 0; i < count; i++)
 NSLog (@"Element DF %i = %@", i, [arrayDF objectAtIndex: i]);
 
 
 
 
 
 
 NSString * configPath;
 NSMutableDictionary *appConfigurations = [[NSDictionary dictionaryWithContentsOfFile:configPath] mutableCopy];
 
 if([appConfigurations count] == 0)
 {
 [NSException raise:@"RPC Configurations Exception" format:@"Unable to load RPC Configurations file"];
 }
 return appConfigurations;
 }
 */


-(void)loadConfigProperties
{
    /*NSMutableDictionary *appConfig=[[NSMutableDictionary alloc] initWithCapacity:10];
     //NSMutableArray *mutableArray =[[NSMutableArray alloc] initWithObjects:nil];
     NSLog(@"load 1");
     appConfig=(NSMutableDictionary *)[self loadConfigsFromFile];
     NSString *buildConfigString = appConfig[BUILD_CONFIG];
     NSMutableDictionary *Googlebase = appConfig[GOOGLE_SPEECH];
     NSMutableDictionary *Dialogflowbase = appConfig[DIALOG_FLOW];
     
     NSLog(@"load 2");
     Googlebase = [Googlebase objectForKey:[NSString stringWithFormat:@"%@,%@,%@",buildConfigString,@"_",GOOGLE_SPEECH]];
     Dialogflowbase = [Dialogflowbase objectForKey:[NSString stringWithFormat:@"%@,%@,%@",buildConfigString,@"_",DIALOG_FLOW]];
     */
    /*
     NSDictionary *appcnfg = [NSDictionary dictionaryWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"PwCSpeechLibplist" ofType:@"plist"]];
     NSMutableDictionary *Googlebase = appcnfg[GOOGLE_SPEECH];
     NSBundle * mainBundle = [NSBundle mainBundle];
     NSString *value = [mainBundle objectForInfoDictionaryKey:@"Build Config"];
     Googleapiurl=[Googlebase objectForKey:[NSString stringWithFormat:@"%@,%@,%@",value,@"_",URL]];*/
    
    
    Googleapiurl =@"https://speech.googleapis.com/v1/speech:recognize";
    
    
    //[Googlebase objectForKey:[NSString stringWithFormat:@"%@,%@,%@,%@,%@",buildConfigString,@"_",GOOGLE_SPEECH,@"_",URL]];
    Googleapikey = @"AIzaSyDwapYkPPZbDeMMpzLUqLXrAUFazieWQio";
    //[Googlebase objectForKey:[NSString stringWithFormat:@"%@,%@,%@,%@,%@",buildConfigString,@"_",GOOGLE_SPEECH,@"_",SVCAPI_KEY]];
    
    Dialogflowurl =@"https://api.dialogflow.com/v1/query?v=20170712&query=";
    //[Dialogflowbase objectForKey:[NSString stringWithFormat:@"%@,%@,%@,%@,%@",buildConfigString,@"_",DIALOG_FLOW,@"_",URL]];
    Dialogflowtoken =@"bearer bacd9c3198dc43879f075f73310b0fd9";
    //[Dialogflowbase objectForKey:[NSString stringWithFormat:@"%@,%@,%@,%@,%@",buildConfigString,@"_",DIALOG_FLOW,@"_",TOKEN]];
    Dialogflowguid = @"&lang=en&sessionId=706c386c-a1ab-4d93-af43-17f336760047&timezone=America/Los_Angeles";
    //[Dialogflowbase objectForKey:[NSString stringWithFormat:@"%@,%@,%@,%@,%@",buildConfigString,@"_",DIALOG_FLOW,@"_",GUID]];
    NSLog(@"load 3");
    
}

-(void)setSTTPHandler:(id<ISTTPHandler>)aHandler
{
    NSLog(@"SetHandler function of RPCLayer");
    self.iDelegate=aHandler; //assigning directly to the delegate of the IRPC Handler type
}

- (void) startRecording
{
    NSLog(@"Enter Start Recording");
    NSError *error;
    NSDictionary *recordSettings = @{AVEncoderAudioQualityKey:@(AVAudioQualityMax),
                                     AVEncoderBitRateKey: @16,
                                     AVNumberOfChannelsKey: @1,
                                     AVSampleRateKey: @(SAMPLE_RATE)};
    NSURL *soundFileURL = [NSURL fileURLWithPath:[self soundFilePath]];
    [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayAndRecord error:nil];
    [[AVAudioSession sharedInstance] setActive:YES error:nil];
    
    recorder = [[AVAudioRecorder alloc]
                initWithURL:soundFileURL
                settings:recordSettings
                error:&error];
    recorder.delegate = self;
    
    /*
    if (interval > 0)
    {
        NSLog(@"%@",@"Record with duration in Start Recording");
        [recorder recordForDuration:interval];
        [self.iDelegate onSuccess:@"Recording Started with Duration [%d]"];
    }
    else
    {
        NSLog(@"%@",@"Record without duration in Start Recording");
        [recorder record];
        [self.iDelegate onSuccess:@"Recording Started"];
    }
    */
    NSLog(@"%@",@"Record without duration in Start Recording");
    [recorder record];
    [self.iDelegate onSuccess:@"{\"status\" : { \"code\": 200,\"errorType\": \"success\"}}"];
}

- (void) stopRecording
{
    NSLog(@"Enter StopRecording");
    if(recorder != nil)
    {
        if (recorder.recording)
        {
            [recorder stop];
        }
        // [recorder2 deleteRecording ];
        //  recorder2=nil;
    }
    NSLog(@"Recording stopped in StopRecording");
    // NSLog(@"Call GoogleWork in StopRecording");
    // NSString * s=[self soundFilePath];
    // [self GoogleWork:s];
}

- (void)audioRecorderDidFinishRecording:(AVAudioRecorder *)recorder successfully:(BOOL)flag
{
    NSLog(@"Enter audioRecorderDidFinish");
    //call back the selector called in start recording
    // [self releaserecorder];
    //NSLog(@"recording stopped in audioRecorderDidFinish");
    NSString *stringResult = [NSString stringWithFormat:@"%@", flag ? @"1" : @"0"];
    if (flag){
        NSLog(@"Success in audioRecorderDidFinish");
        NSString * s=[self soundFilePath];
        NSLog(@"Call Google Work in audioRecorderDidFinish");
        [self callSpeechToTextAPI:s];
    }
    else
    {
        NSLog(@"Call Error in audioRecorderDidFinish");
        NSDictionary *userInfo = @{
                                   NSLocalizedDescriptionKey: NSLocalizedString(@"Audio recording stop error.", nil),
                                   NSLocalizedFailureReasonErrorKey: NSLocalizedString(stringResult, nil)
                                   };
        NSError *error = [NSError errorWithDomain:STTPLibErrorDomain
                                             code:AudioRecorderStopError
                                         userInfo:userInfo];
        //Callback error fuction
        [self.iDelegate onError:error];
    }
}

- (void) callSpeechToTextAPI:(NSString *)soundFilePath
{
    NSLog(@"Enter Google Work");
    [self loadConfigProperties];
    NSLog(@"Load Config in Google Work");
    NSString *service = Googleapiurl;
    service = [service stringByAppendingString:@"?key="];
    //Google Speech access token for apunj001@gmail.com will be changed to another value for PwC project
    service = [service stringByAppendingString: Googleapikey];
    
    
    NSData *audioData = [NSData dataWithContentsOfFile:soundFilePath];
    NSDictionary *configRequest = @{@"encoding":@"LINEAR16",
                                    @"sampleRateHertz":@(SAMPLE_RATE),
                                    @"languageCode":@"en-US",
                                    @"maxAlternatives":@30};
    NSDictionary *audioRequest = @{@"content":[audioData base64EncodedStringWithOptions:0]};
    NSDictionary *requestDictionary = @{@"config":configRequest,
                                        @"audio":audioRequest};
    NSError *error;
    NSData *requestData = [NSJSONSerialization dataWithJSONObject:requestDictionary
                                                          options:0
                                                            error:&error];
    NSString *path = service;
    NSURL *URL2 = [NSURL URLWithString:path];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:URL2];
    // if your API key has a bundle ID restriction, specify the bundle ID like this:
    [request addValue:[[NSBundle mainBundle] bundleIdentifier] forHTTPHeaderField:@"X-Ios-Bundle-Identifier"];
    NSString *contentType = @"application/json";
    [request addValue:contentType forHTTPHeaderField:@"Content-Type"];
    [request setHTTPBody:requestData];
    [request setHTTPMethod:@"POST"];
    // dispatch_semaphore_t sem = dispatch_semaphore_create(0);
    
    NSURLSessionTask *task =
    [[NSURLSession sharedSession]
     dataTaskWithRequest:request
     completionHandler:
     ^(NSData *data, NSURLResponse *response, NSError *error) {
         dispatch_async(dispatch_get_main_queue(),
                        ^{
                            NSString *stringResult = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                            NSLog(@"Call success in Google Work string result: [%@]", stringResult);
                            
                            NSError *jsonError = nil;
                            id jsonObject = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&jsonError];
                            NSLog(@"Call success in Google Work json result: [%@]", jsonObject);
                            if (error || jsonError)
                            {
                                NSError *sendError = [[NSError alloc] init];
                                if (error) {
                                    NSLog(@"Call error in Google Work error [%@]", [error localizedDescription]);
                                    sendError = error;
                                } else {
                                    NSLog(@"Call error in Google Work JsonError [%@]", [jsonError localizedDescription]);
                                    sendError = jsonError;
                                }
                                //Callback error fuction
                                [self.iDelegate onError:sendError];
                            }
                            else
                            {
                                if ([NSJSONSerialization isValidJSONObject:jsonObject]) {
                                    NSLog(@"Valid JSON Object");
                                    NSMutableString* strIntentKey = [NSMutableString stringWithString:@""];
                                    if ([jsonObject isKindOfClass:[NSArray class]]) {
                                        NSArray* jsonArray = (NSArray *) jsonObject;
                                        NSLog(@"Inside Kind of NSArray [%@]", jsonArray);
                                        [jsonArray enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
                                            NSLog(@"Inside enumeration [%lu]", (unsigned long)idx);
                                            if ([obj isKindOfClass:[NSDictionary class]] && [(NSDictionary*) obj objectForKey:@"alternatives"]) {
                                                NSLog(@"Found alternatives [%@]", (NSDictionary*) obj);
                                                NSMutableArray *mArrayAlt = [(NSDictionary*) obj mutableArrayValueForKey:@"alternatives"];
                                                NSLog(@"alternatives value [%@]", mArrayAlt);
                                                NSDictionary* resultObject = [mArrayAlt objectAtIndex:0];
                                                [strIntentKey setString:[resultObject valueForKey:@"transcript"]];
                                                NSLog(@"Found my string [%@]", strIntentKey);
                                                *stop = YES;
                                            }
                                        }];
                                    } else if (([jsonObject isKindOfClass:[NSDictionary class]])) {
                                        NSLog(@"Inside Kind of NSDictionary [%@]", [jsonObject valueForKey:@"results"]);
                                        // to be done
                                        //NSLog(@"results [%@]", [jsonObject valueForKey:@"results"]);
                                        //NSLog(@"alternatives [%@]", [[jsonObject valueForKey:@"results"] valueForKey:@"alternatives"]);
                                        //NSLog(@"First Value [%@]", [[[jsonObject valueForKey:@"results"] valueForKey:@"alternatives"] objectAtIndex:0]);
                                        //NSLog(@"First Value Transcript [%@]", [[[[jsonObject valueForKey:@"results"] valueForKey:@"alternatives"] objectAtIndex:0] objectAtIndex:0]);
                                        //NSLog(@"First Value Transcript#1 [%@]", [[[[[jsonObject valueForKey:@"results"] valueForKey:@"alternatives"] objectAtIndex:0] objectAtIndex:0] valueForKey:@"transcript"]);
                                        [strIntentKey setString:[[[[[jsonObject valueForKey:@"results"] valueForKey:@"alternatives"] objectAtIndex:0] objectAtIndex:0] valueForKey:@"transcript"]];
                                        
                                    } else {
                                        NSLog(@"Error Condition Returning");
                                        NSDictionary *userInfo = @{
                                                                   NSLocalizedDescriptionKey: NSLocalizedString(@"Google Speech Response Error.#1", nil),
                                                                   NSLocalizedFailureReasonErrorKey: NSLocalizedString(stringResult, nil)
                                                                   };
                                        NSError *objError = [NSError errorWithDomain:STTPLibErrorDomain
                                                                                code:GoogleSpeechAPIError
                                                                            userInfo:userInfo];
                                        [self.iDelegate onError:objError];
                                        return;
                                    }
                                    NSLog(@"Call Dialogflow");
                                    NSLog(@"send the string to dialog flow [%@]", strIntentKey);
                                    [self Dialogflow:strIntentKey];
                                }
                                else {
                                    NSLog(@"InValid JSON Object");
                                    NSDictionary *userInfo = @{
                                                               NSLocalizedDescriptionKey: NSLocalizedString(@"Google Speech Response Error.#2", nil),
                                                               NSLocalizedFailureReasonErrorKey: NSLocalizedString(stringResult, nil)
                                                               };
                                    NSError *objError = [NSError errorWithDomain:STTPLibErrorDomain
                                                                            code:GoogleSpeechAPIError
                                                                        userInfo:userInfo];
                                    [self.iDelegate onError:objError];
                                }
                            }
                        });
     }];
    [task resume];
    return;
}


- (void) Dialogflow:(NSString *)textstring
{
    NSLog(@"Enter Dialog flow Work");
    [self loadConfigProperties];
    NSLog(@"Load config in Dialog flow Work");
    NSString *service2;
    service2 = Dialogflowurl;
    service2 = [service2 stringByAppendingString:textstring];
    //session id is just a guid can be generated
    service2= [service2 stringByAppendingString: Dialogflowguid ];
    
    NSString* encodedUrl =
    [service2 stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
    NSString *path2= encodedUrl;
    NSURL *URL2 = [NSURL URLWithString:path2];
    
    NSMutableURLRequest *request2 = [NSMutableURLRequest requestWithURL:URL2];
    //Passing Client access token
    NSString *contentType2 = Dialogflowtoken;
    [request2 addValue:contentType2 forHTTPHeaderField:@"Authorization"];
    //   [request2 setHTTPBody:requestData];
    [request2 setHTTPMethod:@"GET"];
    NSLog(@"before task2!");
    NSURLSessionTask *task2 =
    [[NSURLSession sharedSession]
     dataTaskWithRequest:request2
     completionHandler:
     ^(NSData *data, NSURLResponse *response, NSError *error) {
         dispatch_async(dispatch_get_main_queue(), ^{
             NSLog(@"this worked!");
             NSString *stringResult = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
             NSLog(@"Call success in Google Work string result: [%@]", stringResult);
             
             NSError *jsonError = nil;
             id jsonObject = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:&jsonError];
             NSLog(@"Call success in Dialog Flow json result: [%@]", jsonObject);
             if (error || jsonError)
             {
                 NSError *sendError = [[NSError alloc] init];
                 if (error) {
                     NSLog(@"Call error in Dialog Flow error [%@]", [error localizedDescription]);
                     sendError = error;
                 } else {
                     NSLog(@"Call error in Dialog Flow JsonError [%@]", [jsonError localizedDescription]);
                     sendError = jsonError;
                 }
                 //Callback error fuction
                 [self.iDelegate onError:sendError];
             }
             else
             {
                 NSString *stringResult = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                 NSLog(@"Call success in Dialog flow Work");
                 NSLog(@"%@", stringResult);
                 [self.iDelegate onSuccess:stringResult];
             }
         });
     }];
    NSLog(@"before resume!");
    [task2 resume];
    return;
}

-(void) playRecording
{
    NSLog(@"%@",@"Enter PlayRecording");
    /*
     PwCfunctioncallbackobjectend=obj;
     
     PwCfunctioncallbacksend = @[NSStringFromSelector(oneParameterSelectorG),NSStringFromSelector(oneParameterSelectorerrorG)];
     SEL oneParameterSelector = @selector(methodWithoneParameter:);
     AVSpeechUtterance *utterance = [AVSpeechUtterance
     speechUtteranceWithString:result];
     AVSpeechSynthesizer *synth = [[AVSpeechSynthesizer alloc] init];
     [synth speakUtterance:utterance];
     
     [obj performSelector:oneParameterSelectorG withObject:(id)result ];
     */
}

-(NSDictionary  *) GetParsedResult:(NSString *)result
{
    NSError * error;
    
    NSData * data;
    
    NSDictionary *jsonResponse;
    
    NSDictionary *res;
    
    @try {
        
        data = [result dataUsingEncoding:NSUTF8StringEncoding];
        jsonResponse = [NSJSONSerialization JSONObjectWithData:data
                                                       options:kNilOptions error:&error];
        res= jsonResponse[@"result"];
        
        //Input Context and output context
        NSLog(@"%@",res[@"contexts"][0][@"name"]);
        
        return res;
    }
    @catch ( NSException *e ) {
        
        @throw e;
    }
    
    @finally {
        res=nil;
        jsonResponse=nil;
    }
    
}

-(NSString *) GetOutputText:(NSString *)result
{
    NSDictionary * col;
    
    @try {
        
        col=[self GetParsedResult:result];
        
        NSLog(@"%@",col[@"parameters"][@"clientname"]);
        //NSDictionary *contexts= res[@"contexts"];
        
        
        return col[@"fulfillment"][@"messages"][0][@"speech"];
    } @catch ( NSException *e ) {
        
        @throw e;
    }
    
    @finally {
        
    }
    
}

-(NSString *) GetIntentMatched:(NSString *)result
{
    NSDictionary * col;
    
    @try {
        
        col=[self GetParsedResult:result];
        
        NSLog(@"%@",col[@"metadata"][@"intentName"]);
        
        
        return col[@"metadata"][@"intentName"];
    } @catch ( NSException *e ) {
        
        @throw e;
    }
    
    @finally {
        
    }
    
    
    
}
-(NSString *) GetOutputContextMatched:(NSString *)result{
    
    NSDictionary * col;
    
    @try {
        
        col=[self GetParsedResult:result];
        
        NSLog(@"%@",col[@"contexts"][0][@"name"]);
        
        
        return col[@"contexts"][0][@"name"];
    } @catch ( NSException *e ) {
        
        @throw e;
    }
    
    @finally {
        
    }
    
    
    
}

@end


