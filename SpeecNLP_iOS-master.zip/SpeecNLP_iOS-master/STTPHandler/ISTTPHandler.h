//
//  ISTTPHandler.h
//  SpeechNLPLib
//
//  Created by Padman Balasubramanian on 2/14/18.
//  Copyright © 2018 PricewaterhouseCoopers LLP. All rights reserved.
//

#ifndef ISTTPHandler_h
#define ISTTPHandler_h

@protocol ISTTPHandler

@required

-(void)onSuccess:(NSString *)aStrToken;
-(void)onError:(NSError *)aError;

@end
#endif /* ISTTPHandler_h */
